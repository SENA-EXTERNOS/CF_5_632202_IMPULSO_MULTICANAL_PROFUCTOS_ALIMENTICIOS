function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xAYe5PnREJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

